import nltk
import spacy
from nltk.chat.util import Chat, reflections

# Download necessary NLTK data if not available
nltk.download('punkt')
nltk.download('wordnet')

# Load SpaCy NLP model
try:
    nlp = spacy.load("en_core_web_sm")
except OSError:
    from spacy.cli import download
    download("en_core_web_sm")
    nlp = spacy.load("en_core_web_sm")

# Define general customer support conversational pairs
pairs = [
    ['hi|hello|hey', ['Hello! How can I assist you with your inquiry today?']],
    ['(.*) order status', ['Please provide your order ID to check the status.']],
    ['(.*) refund policy', ['We provide a 10-day refund policy on eligible items.']],
    ['(.*) cancel my order', ['To cancel an order, please go to your orders page and select "Cancel".']],
    ['(.*) return policy', ['You can return items within 30 days if they meet return conditions.']],
    ['(.*) payment options', ['We accept Credit Cards, Debit Cards, UPI, Net Banking, and Wallets.']],
    ['bye|exit', ['Thank you for reaching out! Have a great day!']]
]

# Initialize NLTK Chat
chatbot = Chat(pairs, reflections)

# Custom NLP response function
def get_response(user_input):
    # Process the input with SpaCy for advanced NLP processing
    doc = nlp(user_input.lower())

    # Custom rule-based responses for specific keywords
    if 'order' in user_input.lower():
        return "Please share your order ID for assistance."
    elif 'refund' in user_input.lower():
        return "Our refund policy allows you to get your money back within 10 days for eligible products."
    elif 'payment' in user_input.lower():
        return "We support multiple payment options, including Credit/Debit cards and UPI."
    elif 'cancel' in user_input.lower() and 'order' in user_input.lower():
        return "To cancel an order, please go to your orders page and select 'Cancel'."
    
    # Use NLTK Chatbot for general responses
    return chatbot.respond(user_input)
